import ResetPassword from "../features/auth/components/ResetPassword";

function ResetPasswordPage() {
    return ( <div>
        <ResetPassword></ResetPassword>
    </div>  );
}

export default ResetPasswordPage;